reFocus for XBMC
============

reFocus is a reimaging of the original Focus skin released in 2008 and was created from the ground up. and although visually there are a lot of differences it shares the same philosophy as it's predecessor. Which is to provide a clean, minimalistic and smooth user experience, putting your media at the center of your experience.

http://forum.xbmc.org/forumdisplay.php?fid=72

license: http://creativecommons.org/licenses/by-nc-sa/3.0/
